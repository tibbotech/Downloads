#include "sysheaders.h"

#include "config.h"
#include "vspm.h"

/* ioctls */
#include "ioctl_sys.h"
#include "ioctl_vspm.h"
#include "ioctl_vspd.h"

#define DEBUG_IOCTL_S 0x04
#define DEBUG_IOCTL_D 0x08
#define DEBUG_POLL 0x10

#ifdef LINUX
#if LINUX_VERSION_CODE < KERNEL_VERSION(2,2,0)
#error "LINUX kernel version > 2.2.0 required"
#endif /* LINUX_VERSION_CODE */
#endif /* LINUX */
#ifdef BSD
#ifndef BSD4_3
#error "BSD kernel version > 4.3 required"
#endif /* BSD_VERSION_CODE */
#endif /* BSD */

struct VSP_ROOT rootdev;

/* device parameters */
int major0 = VSP_MAJOR0;
int major1 = VSP_MAJOR1;
int debug = VSP_DEBUG;
int maxdev = VSP_MAXDEV;
#ifdef LINUX
#if LINUX_VERSION_CODE < KERNEL_VERSION(2,6,17)
#ifdef MODULE_PARM
MODULE_PARM( major0, "i");
MODULE_PARM( major1, "i");
MODULE_PARM( debug, "i");
MODULE_PARM( maxdev, "i");
#endif /* MODULE_PARM */
#else
module_param( major0, int, VSP_MAJOR0);
module_param( major1, int, VSP_MAJOR1);
module_param( debug, int, VSP_DEBUG);
module_param( maxdev, int, VSP_MAXDEV);
#endif
MODULE_PARM_DESC( major0, "Major number for tty devices");
MODULE_PARM_DESC( major1, "Major number for daemon interface devices");
MODULE_PARM_DESC( debug, "Debug level (0-2)");
MODULE_PARM_DESC( maxdev, "Max. number of devices");
#endif /* LINUX */

static int vsp_open( struct VSP_ROOT *_root, struct VSP_DEV *_dev, struct tty_struct *_tty) {
 int ret = VSP_SUCCESS, sret = 0;
 _tty->driver_data = NULL;
 if ( !_dev) return( -ENODEV);
 sret = vsp_sema_down( _dev->sem);
 if ( _dev->usage >= _dev->max_open) {  ret = -EBUSY;  goto out;  }
/* dev_confs[ num].pp = VSP_PID; */
 VSP_MOD_INC_USAGE;
 _dev->usage++;
 _tty->driver_data = _dev;
 _dev->ttyp = _tty;
 if ( _dev->usage > 1) goto out;
 _tty->real_raw = 1;
 out:
 vsp_sema_up( _dev->sem);
 if ( debug) KLOG( "[%s] %s %s by (%i)%s ret:%d\n", VSP_MOD_NAME, __FUNCTION__, _dev->name, VSP_PID, VSP_PCOMM, ret);
 return( ret);  }
static int vsps_open( struct tty_struct *_tty, struct file *_file) {
 if ( VSP_PORTN( _tty) >= rootdev.maxdev) return( -ENODEV);
 return( vsp_open( &rootdev, &( rootdev.devices_S[ VSP_PORTN( _tty)]), _tty));  }
static int vspd_open( struct tty_struct *_tty, struct file *_file) {
 if ( VSP_PORTN( _tty) >= rootdev.maxdev) return( -ENODEV);
 return( vsp_open( &rootdev, &( rootdev.devices_D[ VSP_PORTN( _tty)]), _tty));  }

static int vsp_release( struct VSP_ROOT *_root, struct VSP_DEV *_dev) {
 int ret = VSP_SUCCESS;
 if ( !_dev) return( -ENODEV);
 vsp_sema_down( _dev->sem);
 if ( _dev->usage <= 0) {  goto out;  }
 VSP_MOD_DEC_USAGE;
 _dev->usage--;
 if ( _dev->usage < 1) _dev->ttyp = NULL;
 out:
 vsp_sema_up( _dev->sem);
 if ( debug) KLOG( "[%s] %s closed(%d) by (%i)%s\n", VSP_MOD_NAME, _dev->name, ret, VSP_PID, VSP_PCOMM);
 return( ret);  }
static void vsps_release( struct tty_struct *_tty, struct file *_file) {
 if ( VSP_PORTN( _tty) >= rootdev.maxdev) return;
 vsp_release( &rootdev, &( rootdev.devices_S[ VSP_PORTN( _tty)]));  }
static void vspd_release( struct tty_struct *_tty, struct file *_file) {
 if ( VSP_PORTN( _tty) >= rootdev.maxdev) return;
 vsp_release( &rootdev, &( rootdev.devices_D[ VSP_PORTN( _tty)]));  }

/* _fu == 0 - from kernel, else - from userspace */
static ssize_t vsp_write( struct VSP_ROOT *_root, struct VSP_DEV *_dev, const unsigned char *_buff, size_t _len, int _fu, int _nonb, struct tty_struct *_tty) {
 int sret = 0, i, ltc, dl = 0;
 unsigned char tmpbuf[ TTY_FLIPBUF_SIZE];
 /* if write to file ==> dev = file (F->F) 0->1 */
 /* if write to port ==> dev = port (S->S) 1->0 */
 if ( debug) KLOG( "[%s] WX to %s start\n", VSP_MOD_NAME, _dev->name);
 if ( !_dev) return( -ENODEV);
 if ( !_dev->ttyp) return( 0);
 if ( _len < 1) return( 0);
/* critical section */
 if ( !_fu) vsp_sema_down( _dev->sem);
 ltc = min( TTY_FLIPBUF_SIZE, ( int)_len);
 if ( ltc < 1 && _len == 1) {  sret = 1;  goto out;  }
 if ( _fu) {  UTK( tmpbuf, _buff, ltc);  }
  else memcpy( tmpbuf, _buff, ltc);

 if ( debug > 2) KLOG( "[%s] WX to %s:", VSP_MOD_NAME, _dev->name);
 for ( i = 0; i < ltc; i++) {
   if ( debug > 2) KLOG( "%02X", tmpbuf[ i]);
   tty_insert_flip_char( _dev->ttyp, tmpbuf[ i], TTY_NORMAL);
   dl++;  }
 if ( debug > 2) KLOG( "%s\n", "END");
 if ( debug) KLOG( "[%s] %s %s dl(%d)\n", VSP_MOD_NAME, _dev->name, __FUNCTION__, dl);
 tty_flip_buffer_push( _dev->ttyp);
 sret = dl;
 out:
 if ( !_fu) vsp_sema_up( _dev->sem);
#if LINUX_VERSION_CODE >= KERNEL_VERSION(2,4,30)
 tty_wakeup( _tty);
#endif
/* critical section end */
 if ( debug) KLOG( "[%s] WX to %s ret:%d\n", VSP_MOD_NAME, _dev->name, sret);
 return( sret);  }
#if LINUX_VERSION_CODE < KERNEL_VERSION(2,6,10)
static int vsps_write( struct tty_struct *_tty, int _fu, const unsigned char *_buff, int _count) {
 if ( VSP_PORTN( _tty) >= rootdev.maxdev) return( -ENODEV);
 return( vsp_write( &rootdev, &( rootdev.devices_D[ VSP_PORTN( _tty)]), _buff, _count, _fu, 0, _tty));  }
static int vspd_write( struct tty_struct *_tty, int _fu, const unsigned char *_buff, int _count) {
 if ( VSP_PORTN( _tty) >= rootdev.maxdev) return( -ENODEV);
 return( vsp_write( &rootdev, &( rootdev.devices_S[ VSP_PORTN( _tty)]), _buff, _count, _fu, 0, _tty));  }
#endif /* LINUX_VERSION_CODE */
#if LINUX_VERSION_CODE > KERNEL_VERSION(2,6,9)
static int vsps_write( struct tty_struct *_tty, const unsigned char *_buff, int _count) {
 if ( VSP_PORTN( _tty) >= rootdev.maxdev) return( -ENODEV);
 return( vsp_write( &rootdev, &( rootdev.devices_D[ VSP_PORTN( _tty)]), _buff, _count, 0, 0, _tty));  }
static int vspd_write( struct tty_struct *_tty, const unsigned char *_buff, int _count) {
 if ( VSP_PORTN( _tty) >= rootdev.maxdev) return( -ENODEV);
 return( vsp_write( &rootdev, &( rootdev.devices_S[ VSP_PORTN( _tty)]), _buff, _count, 0, 0, _tty));  }
#endif /* LINUX_VERSION_CODE */

static int vsp_write_room( struct VSP_DEV *_dev) {
 int ret = TTY_FLIPBUF_SIZE;
 if ( debug > 2) KLOG( "[%s] %s for %s ret:%d by %s(%d)\n", VSP_MOD_NAME, __FUNCTION__, _dev->name, ret, VSP_PCOMM, VSP_PID);
 return( ret);  }
static int vsps_write_room( struct tty_struct *_tty) {
 return( vsp_write_room( &( rootdev.devices_S[ VSP_PORTN( _tty)])));  }
static int vspd_write_room( struct tty_struct *_tty) {
 return( vsp_write_room( &( rootdev.devices_D[ VSP_PORTN( _tty)])));  }

static int vsp_chars_in_buffer( struct VSP_DEV *_dev) {
 int ret = 0;
 if ( debug > 2) KLOG( "[%s] %s for %s ret:%d by %s(%d)\n", VSP_MOD_NAME, __FUNCTION__, _dev->name, ret, VSP_PCOMM, VSP_PID);
 return( ret);  }
static int vsps_chars_in_buffer( struct tty_struct *_tty) {
 return( vsp_chars_in_buffer( &( rootdev.devices_S[ VSP_PORTN( _tty)])));  }
static int vspd_chars_in_buffer( struct tty_struct *_tty) {
 return( vsp_chars_in_buffer( &( rootdev.devices_D[ VSP_PORTN( _tty)])));  }

int vsp_get_termios( struct VSP_KTERMIOS *_trsp, void *_arg, unsigned int _cmd) {
 if ( _cmd == TCGETA) {
   if ( kernel_termios_to_user_termio( ( struct VSP_TERMIO *)_arg, _trsp)) return( -EFAULT);
   return( VSP_SUCCESS);  }
 // TCGETS* section
#ifndef TCGETS2
 if ( kernel_termios_to_user_termios( ( struct VSP_TERMIOS *)_arg, _trsp)) return( -EFAULT);
#else
 if ( _cmd == TCGETS) {
   if ( kernel_termios_to_user_termios_1( ( struct VSP_TERMIOS *)_arg, _trsp)) return( -EFAULT);
 }
 if ( _cmd == TCGETS2) {
   if ( kernel_termios_to_user_termios( ( struct VSP_TERMIOS2 *)_arg, _trsp)) return( -EFAULT);
 }
#endif
 return( VSP_SUCCESS);  }

int vsp_set_termios( void *_arg, struct VSP_KTERMIOS *_trsp, unsigned int _cmd) {
 switch ( _cmd) {
   case TCSETAW:	/* (1) change after transmit */
   case TCSETAF:	/* (2) flush buffer */
   case TCSETA:
     if ( user_termio_to_kernel_termios( _trsp, ( struct VSP_TERMIO *)_arg)) return( -EFAULT);
     break;
   case TCSETSW:	/* (1) change after transmit */
   case TCSETSF:	/* (2) flush buffer */
   case TCSETS:
#ifdef TCGETS2
     if ( user_termios_to_kernel_termios_1( _trsp, ( struct VSP_TERMIOS *)_arg)) return( -EFAULT);
#else
     if ( user_termios_to_kernel_termios( _trsp, ( struct VSP_TERMIOS *)_arg)) return( -EFAULT);
#endif
     break;
#ifdef TCGETS2
   case TCSETSW2:	/* (1) change after transmit */
   case TCSETSF2:	/* (2) flush buffer */
   case TCSETS2:
     if ( user_termios_to_kernel_termios( _trsp, ( struct VSP_TERMIOS2 *)_arg)) return( -EFAULT);
     break;
#endif
 }
 return( VSP_SUCCESS);  }

static int vsp_ioctl_S( struct VSP_ROOT *_root, int _num, unsigned int _cmd, unsigned long _arg, struct tty_struct *_tty, struct file *_file) {	
 struct VSP_DEVC *dev_conf = &( _root->dev_confs[ _num]);
 unsigned int argg = 0;
 unsigned short tmp_short = 0;
 struct tty_struct *tty_arg, *tty_real;
 int ret;
 if ( debug > 2) KLOG( "[%s] %s CMD0x%X try\n", VSP_MOD_NAME, __FUNCTION__, _cmd);
 if ( VSP_IOCC_TYPE( _cmd) != VSPM_IOCTL_MAGIC) {
#if LINUX_VERSION_CODE < KERNEL_VERSION(2,6,27)
   if ( _tty->ldisc.ioctl) {
#elif LINUX_VERSION_CODE <= KERNEL_VERSION(2,6,30)
   if ( _tty->ldisc.ops->ioctl) {
#else
   if ( _tty->ldisc->ops->ioctl) {
#endif
     KLOG( "[%s] %s calling _tty->ldisc.ioctl for CMD0x%X\n", VSP_MOD_NAME, __FUNCTION__, _cmd);
#if LINUX_VERSION_CODE < KERNEL_VERSION(2,6,27)
     ret = _tty->ldisc.ioctl( _tty, _file, _cmd, _arg);
#elif LINUX_VERSION_CODE <= KERNEL_VERSION(2,6,30)
     ret = _tty->ldisc.ops->ioctl( _tty, _file, _cmd, _arg);
#else
     ret = _tty->ldisc->ops->ioctl( _tty, _file, _cmd, _arg);
#endif
//     ret = _tty->ldisc.ioctl( _tty, _file, _cmd, _arg);
     KLOG( "[%s] %s _tty->ldisc.ioctl for CMD0x%X ret:%d\n", VSP_MOD_NAME, __FUNCTION__, _cmd, ret);
     if ( ret != -ENOIOCTLCMD) return( ret);  }
   KLOG( "[%s] %s CMD0x%X bad magic\n", VSP_MOD_NAME, __FUNCTION__, _cmd);
   return( -ENOIOCTLCMD);  }
 dev_conf->hioctl = 1;
 switch ( _cmd) {
   case TCSBRK: /* wait for output to drain */
     if ( debug & DEBUG_IOCTL_S) KLOG( "[%s] %s TCSBRK\n", VSP_MOD_NAME, __FUNCTION__);
     break;
   case TCXONC: /* start/stop control */
     if ( debug & DEBUG_IOCTL_S) KLOG( "[%s] %s TCXONC\n", VSP_MOD_NAME, __FUNCTION__);
     break;
   case TCFLSH: /* flush ... buffer */
     if ( debug & DEBUG_IOCTL_S) KLOG( "[%s] %s TCFLUSH\n", VSP_MOD_NAME, __FUNCTION__);
     break;
   case TCGETA:
   case TCGETS:
#ifdef TCGETS2
   case TCGETS2:
#endif
     if ( debug & DEBUG_IOCTL_S) KLOG( "[%s] %s TCGET*\n", VSP_MOD_NAME, __FUNCTION__);
     return( vsp_get_termios( &( dev_conf->trs), ( void *)_arg, _cmd));
     break;
   case TCSETSW:	/* (1) change after output transmitted - FIXME */
   case TCSETSF:	/* (2) + flush input buffer - FIXME */
   case TCSETS:
#ifdef TCGETS2
   case TCSETSW2:	/* (1) --//-- */
   case TCSETSF2:	/* (2) --//-- */
   case TCSETS2:
#endif
   case TCSETAW:	/* (1) --//-- */
   case TCSETAF:	/* (2) --//-- */
   case TCSETA:
     if ( debug & DEBUG_IOCTL_S) KLOG( "[%s] %s TCSET*\n", VSP_MOD_NAME, __FUNCTION__);
     return( vsp_set_termios( ( void *)_arg, &( dev_conf->trs), _cmd));
     break;
   case TIOCGPGRP:
     if ( debug & DEBUG_IOCTL_S) KLOG( "[%s] %s TIOCGPGRP\n", VSP_MOD_NAME, __FUNCTION__);
     if ( VSP_ACCESS_OK( VERIFY_WRITE, ( void *)_arg, sizeof( pid_t)) == 0) return( -EFAULT);
     KTU( ( void *)_arg, &( dev_conf->pg), sizeof( pid_t));
     break;
   case TIOCSPGRP:
     if ( debug & DEBUG_IOCTL_S) KLOG( "[%s] %s TIOCSPGRP\n", VSP_MOD_NAME, __FUNCTION__);
     if ( VSP_ACCESS_OK( VERIFY_READ, ( void *)_arg, sizeof( pid_t)) == 0) return( -EFAULT);
     UTK( &( dev_conf->pg), ( void *)_arg, sizeof( pid_t));
     break;
/*   case TIOCGSID:
     if ( VSP_ACCESS_OK( VERIFY_WRITE, ( void *)_arg, sizeof( pid_t)) == 0) return( -EFAULT);
     KTU( ( void *)_arg, &( dev_conf->pp), sizeof( pid_t));
     break;
*/
   case TIOCGWINSZ:
     if ( debug & DEBUG_IOCTL_S) KLOG( "[%s] %s TIOCGWINSZ\n", VSP_MOD_NAME, __FUNCTION__);
     if ( VSP_ACCESS_OK( VERIFY_WRITE, ( void *)_arg, sizeof( struct winsize)) == 0) return( -EFAULT);
     KTU( ( void *)_arg, &( dev_conf->win), sizeof( struct winsize));
     break;
   case TIOCSWINSZ:
     if ( debug & DEBUG_IOCTL_S) KLOG( "[%s] %s TIOCSWINSZ\n", VSP_MOD_NAME, __FUNCTION__);
     if ( VSP_ACCESS_OK( VERIFY_READ, ( void *)_arg, sizeof( struct winsize)) == 0) return( -EFAULT);
     UTK( &( dev_conf->win), ( void *)_arg, sizeof( struct winsize));
     break;
   case TIOCMGET:
     if ( debug & DEBUG_IOCTL_S) KLOG( "[%s] %s TIOCMGET\n", VSP_MOD_NAME, __FUNCTION__);
     if ( VSP_ACCESS_OK( VERIFY_WRITE, ( void *)_arg, sizeof( unsigned int)) == 0) return( -EFAULT);
     KTU( ( void *)_arg, &( dev_conf->lines), sizeof( unsigned int));
     break;
   case TIOCMSET:
     if ( debug & DEBUG_IOCTL_S) KLOG( "[%s] %s TIOCMSET\n", VSP_MOD_NAME, __FUNCTION__);
     if ( VSP_ACCESS_OK( VERIFY_READ, ( void *)_arg, sizeof( unsigned int)) == 0) return( -EFAULT);
     UTK( &( dev_conf->lines), ( void *)_arg, sizeof( unsigned int));
     break;
   case TIOCMBIS:
     if ( debug & DEBUG_IOCTL_S) KLOG( "[%s] %s TIOCMBIS\n", VSP_MOD_NAME, __FUNCTION__);
     if ( VSP_ACCESS_OK( VERIFY_READ, ( void *)_arg, sizeof( unsigned int)) == 0) return( -EFAULT);
     UTK( ( void *)&argg, ( void *)_arg, sizeof( unsigned int));
     if ( argg & VSPD_LINES_LINE0) dev_conf->lines |= VSPD_LINES_LINE0;
     if ( argg & VSPD_LINES_LINE1) dev_conf->lines |= VSPD_LINES_LINE1;
     if ( argg & VSPD_LINES_LINE2) dev_conf->lines |= VSPD_LINES_LINE2;
     if ( argg & VSPD_LINES_LINE3) dev_conf->lines |= VSPD_LINES_LINE3;
     if ( argg & VSPD_LINES_LINE4) dev_conf->lines |= VSPD_LINES_LINE4;
     if ( argg & VSPD_LINES_LINE5) dev_conf->lines |= VSPD_LINES_LINE5;
     break;
   case TIOCMBIC:
     if ( debug & DEBUG_IOCTL_S) KLOG( "[%s] %s TIOCMBIC\n", VSP_MOD_NAME, __FUNCTION__);
     if ( VSP_ACCESS_OK( VERIFY_READ, ( void *)_arg, sizeof( unsigned int)) == 0) return( -EFAULT);
     UTK( ( void *)&argg, ( void *)_arg, sizeof( unsigned int));
     if ( argg & VSPD_LINES_LINE0) dev_conf->lines &= ~VSPD_LINES_LINE0;
     if ( argg & VSPD_LINES_LINE1) dev_conf->lines &= ~VSPD_LINES_LINE1;
     if ( argg & VSPD_LINES_LINE2) dev_conf->lines &= ~VSPD_LINES_LINE2;
     if ( argg & VSPD_LINES_LINE3) dev_conf->lines &= ~VSPD_LINES_LINE3;
     if ( argg & VSPD_LINES_LINE4) dev_conf->lines &= ~VSPD_LINES_LINE4;
     if ( argg & VSPD_LINES_LINE5) dev_conf->lines &= ~VSPD_LINES_LINE5;
     break;
   case TIOCEXCL:
     if ( debug & DEBUG_IOCTL_S) KLOG( "[%s] %s TIOCEXCL\n", VSP_MOD_NAME, __FUNCTION__);
     dev_conf->max_open = 1;
     break;
   case TIOCNXCL:
     if ( debug & DEBUG_IOCTL_S) KLOG( "[%s] %s TIOCNXCL\n", VSP_MOD_NAME, __FUNCTION__);
     dev_conf->max_open = VSP_MAXOPEN;
     break;
   case TIOCSETD:
     if ( debug & DEBUG_IOCTL_S) KLOG( "[%s] %s TIOCSETD\n", VSP_MOD_NAME, __FUNCTION__);
     break;
   case FIONREAD:
     if ( debug & DEBUG_IOCTL_S) KLOG( "[%s] %s FIONREAD\n", VSP_MOD_NAME, __FUNCTION__);
     if ( VSP_ACCESS_OK( VERIFY_WRITE, ( void *)_arg, sizeof( unsigned short)) == 0) return( -EFAULT);
// FIXME : write buffer space to tmp_short
     KTU( ( void *)_arg, &tmp_short, sizeof( unsigned short));
     break;
   case TIOCCONS:
     if ( debug & DEBUG_IOCTL_S) KLOG( "[%s] %s TIOCCONS\n", VSP_MOD_NAME, __FUNCTION__);
     tty_arg = ( struct tty_struct *)_file->private_data;
     if ( !tty_arg) return( -ENOTTY);
     if ( debug & DEBUG_IOCTL_S) KLOG( "[%s] %s TIOCCONS 1\n", VSP_MOD_NAME, __FUNCTION__);
     tty_real = tty_arg->link;
     if ( !tty_real) return( -ENOTTY);
     if ( debug & DEBUG_IOCTL_S) KLOG( "[%s] %s TIOCCONS 2\n", VSP_MOD_NAME, __FUNCTION__);
     if ( tty_real != tty_arg) return( -EINVAL);
     // FIXME
     break;
   default:   
     KLOG( "[%s] %s unknown CMD 0x%X\n", VSP_MOD_NAME, __FUNCTION__, _cmd);
     break;
 }
 return( VSP_SUCCESS);  }

static int vsp_ioctl_D( struct VSP_ROOT *_root, int _num, unsigned int _cmd, unsigned long _arg) {
 struct VSP_DEVC *dev_conf = &( _root->dev_confs[ _num]);
 struct VSP_DEV *dev_S = &( _root->devices_S[ _num]);
 if ( VSP_IOCC_TYPE( _cmd) != VSPD_IOCTL_MAGIC) {
   KLOG( "[%s] %s CMD0x%X bad magic\n", VSP_MOD_NAME, __FUNCTION__, _cmd);
   return( -ENOTTY);  }
 if ( VSP_IOCC_DIR( _cmd) & VSP_IOCD_READ)  if ( VSP_ACCESS_OK( VERIFY_WRITE, ( void *)_arg, VSP_IOCC_SIZE( _cmd)) == 0) return( -EFAULT);
 if ( VSP_IOCC_DIR( _cmd) & VSP_IOCD_WRITE) if ( VSP_ACCESS_OK( VERIFY_READ , ( void *)_arg, VSP_IOCC_SIZE( _cmd)) == 0) return( -EFAULT);
 switch ( _cmd) {
   case VSPD_IOGTRM:
     if ( debug & DEBUG_IOCTL_D) KLOG( "[%s] %s VSPD_IOGTRM\n", VSP_MOD_NAME, __FUNCTION__);
     if ( VSP_ACCESS_OK( VERIFY_WRITE, ( void *)_arg, sizeof( struct VSP_TERMIOS)) == 0) return( -EFAULT);
     KTU( ( void *)_arg, &( dev_conf->trs), sizeof( struct VSP_TERMIOS2));
     break;
   case VSPD_IOGLINES:
     if ( debug & DEBUG_IOCTL_D) KLOG( "[%s] %s VSPD_IOGLINES\n", VSP_MOD_NAME, __FUNCTION__);
     if ( VSP_ACCESS_OK( VERIFY_WRITE, ( void *)_arg, sizeof( unsigned int)) == 0) return( -EFAULT);
     KTU( ( void *)_arg, &( dev_conf->lines), sizeof( unsigned int));
     break;
   case VSPD_IOSLINES:
     if ( debug & DEBUG_IOCTL_D) KLOG( "[%s] %s VSPD_IOSLINES\n", VSP_MOD_NAME, __FUNCTION__);
     if ( VSP_ACCESS_OK( VERIFY_READ, ( void *)_arg, sizeof( unsigned int)) == 0) return( -EFAULT);
     UTK( &( dev_conf->lines), ( void *)_arg, sizeof( unsigned int));
     break;
   case VSPD_IOGNUMOP:
     if ( debug & DEBUG_IOCTL_D) KLOG( "[%s] %s VSPD_IOGNUMOP\n", VSP_MOD_NAME, __FUNCTION__);
     if ( VSP_ACCESS_OK( VERIFY_WRITE, ( void *)_arg, sizeof( unsigned char)) == 0) return( -EFAULT);
     KTU( ( void *)_arg, &( dev_S->usage), sizeof( unsigned char));
     break;
   case VSPD_IOGISIOC:
     if ( debug & DEBUG_IOCTL_D) KLOG( "[%s] %s VSPD_IOGISIOC\n", VSP_MOD_NAME, __FUNCTION__);
     if ( VSP_ACCESS_OK( VERIFY_WRITE, ( void *)_arg, sizeof( unsigned char)) == 0) return( -EFAULT);
     KTU( ( void *)_arg, &( dev_conf->hioctl), sizeof( unsigned char));
     break;
   default:
     KLOG( "[%s] %s unknown CMD 0x%X NR:%d TYPE:%d\n", VSP_MOD_NAME, __FUNCTION__, _cmd, VSP_IOCC_NR( _cmd), VSP_IOCC_TYPE( _cmd));
     break;
 }
 return( VSP_SUCCESS);  }

static int vspd_ioctl( struct tty_struct *_tty, struct file *_file, unsigned int _cmd, unsigned long _arg) {
 return( vsp_ioctl_D( &rootdev, VSP_PORTN( _tty), _cmd, _arg));  }
static int vsps_ioctl( struct tty_struct *_tty, struct file *_file, unsigned int _cmd, unsigned long _arg) {
 return( vsp_ioctl_S( &rootdev, VSP_PORTN( _tty), _cmd, _arg, _tty, _file));  }
//#ifdef CONFIG_COMPAT
#ifdef HAVE_COMPAT_IOCTL
#if LINUX_VERSION_CODE > KERNEL_VERSION(2,6,21)
static long vspd_compat_ioctl( struct tty_struct *_tty, struct file *_file, unsigned int _cmd, unsigned long _arg) {
 return( vsp_ioctl_D( &rootdev, VSP_PORTN( _tty), _cmd, _arg));  }
//static long vsps_compat_ioctl( struct tty_struct *_tty, struct file *_file, unsigned int _cmd, unsigned long _arg) {
// return( vsps_ioctl( _tty, _file, _cmd, _arg));  }
#endif
#endif

static void vsps_set_ldisc( struct tty_struct *_tty) {
 char *n;
#if LINUX_VERSION_CODE < KERNEL_VERSION(2,6,27)
 n = _tty->ldisc.name;
#elif LINUX_VERSION_CODE <= KERNEL_VERSION(2,6,30)
 n = _tty->ldisc.ops->name;
#else
 n = _tty->ldisc->ops->name;
#endif
 KLOG( "[%s] %s %s\n", VSP_MOD_NAME, __FUNCTION__, n);
 return;  }
static void vspd_set_ldisc( struct tty_struct *_tty) {
 char *n;
#if LINUX_VERSION_CODE < KERNEL_VERSION(2,6,27)
 n = _tty->ldisc.name;
#elif LINUX_VERSION_CODE <= KERNEL_VERSION(2,6,30)
 n = _tty->ldisc.ops->name;
#else
 n = _tty->ldisc->ops->name;
#endif
 KLOG( "[%s] %s %s\n", VSP_MOD_NAME, __FUNCTION__, n);
 return;  }

/* test funcs start:FIO */
//static void vsps_put_char( struct tty_struct *_tty, unsigned char _ch) {
// unsigned char tmp_buff[ 1];
// tmp_buff[ 0] = _ch;
// if ( debug > 1) KLOG( "[%s] %s\n", VSP_MOD_NAME, __FUNCTION__);
// vsp_write( &rootdev, rootdev.major0, VSP_PORTN( _tty), tmp_buff, 1, 1, 0);
// return;  }
static void vsp_unimpl( const char *_fname) {
 if ( debug) KLOG( "[%s] %s (syscall unimplemented)\n", VSP_MOD_NAME, _fname);
}
static void vsps_set_termios( struct tty_struct *_tty, struct VSP_KTERMIOS *_old) {
 struct VSP_DEVC *dev_conf;
 int num;
 if ( debug) KLOG( "[%s] %s\n", VSP_MOD_NAME, __FUNCTION__);
 if ( _old == NULL) return;
 num = VSP_PORTN( _tty);
 dev_conf = &( rootdev.dev_confs[ num]);
 vsp_set_termios( ( void *)_old, &( dev_conf->trs), TCSETS);  }
static void vspd_set_termios( struct tty_struct *_tty, struct VSP_KTERMIOS *_old) {  vsp_unimpl( __FUNCTION__);  }
static void vsps_throttle( struct tty_struct *_tty) {  vsp_unimpl( __FUNCTION__);  }
static void vspd_throttle( struct tty_struct *_tty) {  vsp_unimpl( __FUNCTION__);  }
static void vsps_unthrottle( struct tty_struct *_tty) {  vsp_unimpl( __FUNCTION__);  }
static void vspd_unthrottle( struct tty_struct *_tty) {  vsp_unimpl( __FUNCTION__);  }
static void vsps_stop( struct tty_struct *_tty) {  vsp_unimpl( __FUNCTION__);  }
static void vspd_stop( struct tty_struct *_tty) {  vsp_unimpl( __FUNCTION__);  }
static void vsps_start( struct tty_struct *_tty) {  vsp_unimpl( __FUNCTION__);  }
static void vspd_start( struct tty_struct *_tty) {  vsp_unimpl( __FUNCTION__);  }
static void vsps_hangup( struct tty_struct *_tty) {  vsp_unimpl( __FUNCTION__);  }
static void vspd_hangup( struct tty_struct *_tty) {  vsp_unimpl( __FUNCTION__);  }
#if LINUX_VERSION_CODE < KERNEL_VERSION(2,6,26)
static void vsps_break_ctl( struct tty_struct *_tty, int _state) {  vsp_unimpl( __FUNCTION__);  }
static void vspd_break_ctl( struct tty_struct *_tty, int _state) {  vsp_unimpl( __FUNCTION__);  }
#else
static int vsps_break_ctl( struct tty_struct *_tty, int _state) {  vsp_unimpl( __FUNCTION__);  return( 0);  }
static int vspd_break_ctl( struct tty_struct *_tty, int _state) {  vsp_unimpl( __FUNCTION__);  return( 0);  }
#endif
static int vsps_tiocmget( struct tty_struct *_tty, struct file *_file) {
 struct VSP_DEVC *dev_conf;
 int num = VSP_PORTN( _tty);
 if ( debug) KLOG( "[%s] %s\n", VSP_MOD_NAME, __FUNCTION__);
 dev_conf = &( rootdev.dev_confs[ num]);
 return( dev_conf->lines);  }
static int vspd_tiocmget( struct tty_struct *_tty, struct file *_file) {  vsp_unimpl( __FUNCTION__);  return( VSP_SUCCESS);  }
static int vsps_tiocmset( struct tty_struct *_tty, struct file *_file, unsigned int _set, unsigned int _clear) {
 struct VSP_DEVC *dev_conf;
 int num = VSP_PORTN( _tty);
 if ( debug) KLOG( "[%s] %s\n", VSP_MOD_NAME, __FUNCTION__);
 dev_conf = &( rootdev.dev_confs[ num]);
 dev_conf->lines = _set;
 return( VSP_SUCCESS);  }
static int vspd_tiocmset( struct tty_struct *_tty, struct file *_file, unsigned int _set, unsigned int _clear) {  vsp_unimpl( __FUNCTION__);  return( VSP_SUCCESS);  }

static void vsps_flush_chars( struct tty_struct *_tty) {
 struct tty_struct *tty;
 int num = VSP_PORTN( _tty);
 if ( num > maxdev) return;
 if ( !( tty = ( rootdev.devices_D[ num]).ttyp)) return;
 tty_schedule_flip( tty);
 return;  }
static void vspd_flush_chars( struct tty_struct *_tty) {
 struct tty_struct *tty;
 int num = VSP_PORTN( _tty);
 if ( num > maxdev) return;
 if ( !( tty = ( rootdev.devices_S[ num]).ttyp)) return;
 tty_schedule_flip( tty);
 return;  }
static void vsps_send_xchar( struct tty_struct *_tty, char ch) {  vsp_unimpl( __FUNCTION__);  }
static void vspd_send_xchar( struct tty_struct *_tty, char ch) {  vsp_unimpl( __FUNCTION__);  }
/* test funcs end:FIO */

/* ------- file operations ------- */
#ifdef LINUX
struct tty_operations Dops = {
 open:            vspd_open,		/* open */
 close:           vspd_release,		/* close */
 write:           vspd_write,		/* write */
 write_room:      vspd_write_room,  /* writeroom */
 chars_in_buffer: vspd_chars_in_buffer,	/* chars */
 ioctl:           vspd_ioctl,      /* ioctl */
//#ifdef CONFIG_COMPAT
#ifdef HAVE_COMPAT_IOCTL
#if LINUX_VERSION_CODE > KERNEL_VERSION(2,6,21)
// compat_ioctl:    vspd_ioctl,  /* ioctl */
 compat_ioctl:    vspd_compat_ioctl,  /* ioctl */
#endif
#endif
 set_termios:	  vspd_set_termios,
 flush_chars:     vspd_flush_chars, /* flush */
/* need test */
// put_char:	  vspd_put_char,
 throttle:	  vspd_throttle,
 unthrottle:	  vspd_unthrottle,
 stop:		  vspd_stop,
 start:		  vspd_start,
 hangup:	  vspd_hangup,
 break_ctl:	  vspd_break_ctl,
 set_ldisc:	  vspd_set_ldisc,
 send_xchar:	  vspd_send_xchar,
#if LINUX_VERSION_CODE > KERNEL_VERSION(2,5,1)
 tiocmget:	  vspd_tiocmget,
 tiocmset:	  vspd_tiocmset,
#endif
};
struct tty_operations Sops = {
 open:            vsps_open,       /* open */
 close:           vsps_release,    /* close */
 write:           vsps_write,      /* write */
 write_room:      vsps_write_room,  /* writeroom */
 chars_in_buffer: vsps_chars_in_buffer,	/* chars */
 ioctl:           vsps_ioctl,      /* ioctl */
//#ifdef CONFIG_COMPAT
#ifdef HAVE_COMPAT_IOCTL
#if LINUX_VERSION_CODE > KERNEL_VERSION(2,6,21)
 compat_ioctl:    NULL,  /* ioctl */
// compat_ioctl:    vsps_compat_ioctl,  /* ioctl */
#endif
#endif
 set_termios:	  vsps_set_termios,
 flush_chars:     vsps_flush_chars, /* flush */
/* need test */
// put_char:	  vsps_put_char,
 throttle:	  vsps_throttle,
 unthrottle:	  vsps_unthrottle,
 stop:		  vsps_stop,
 start:		  vsps_start,
 hangup:	  vsps_hangup,
 break_ctl:	  vsps_break_ctl,
 set_ldisc:	  vsps_set_ldisc,
 send_xchar:	  vsps_send_xchar,
#if LINUX_VERSION_CODE > KERNEL_VERSION(2,5,1)
 tiocmget:	  vsps_tiocmget,
 tiocmset:	  vsps_tiocmset,
#endif
};
#endif /* LINUX */
#ifdef BSD
struct cdevsw Fops = {
 d_open:	vsp_open,
 d_close:	vsp_release,
 d_read:	vsp_read,
 d_write:	vsp_write,
 d_ioctl:	vsp_ioctl,
 d_poll:	vsp_poll,
 d_mmap:	nommap,
 d_strategy:	nostrategy,
 d_name:	VSP_DEV_NAME,
 d_maj:		VSP_MAJOR0,
 d_dump:	nodump,
 d_psize:	nopsize,
 d_flags:	D_TTY,
 d_bmaj:	-1,
 d_kqfilter:	nokqfilter
};
#endif /* BSD */

int __init init_module() {
 int i;
 struct VSP_DEVC *dev_conf;
 if ( maxdev > VSP_MAXDEV) maxdev = VSP_MAXDEV;
 init_termios( &( rootdev.initial_termios));
 rootdev.major0 = major0;
 rootdev.major1 = major1;
 rootdev.debug = debug;
 rootdev.maxdev = maxdev;
 if ( debug > 1) KLOG( "[%s] %s: start\n", VSP_MOD_NAME, __FUNCTION__);
// FIXME
// memset( &( rootdev.redirap), 0, sizeof( struct file *) * VSP_MAXDEV);
 if ( !vsp_register( &rootdev, &Dops, &Sops)) KLOG( "[%s] %s: ROOT device register error\n", VSP_MOD_NAME, __FUNCTION__);
 /* create device */
 if ( debug > 1) KLOG( "[%s] %s: registering devices\n", VSP_MOD_NAME, __FUNCTION__);
 for ( i = 0; i < VSP_MAXDEV; i++) {
   dev_conf = &( rootdev.dev_confs[ i]);
   memset( &( dev_conf->trs), 0, sizeof( struct VSP_KTERMIOS));
   memset( &( dev_conf->win), 0, sizeof( struct winsize));
   dev_conf->hioctl = 0;
   dev_conf->pg = dev_conf->pp = 0;
   dev_conf->lines = 0;
   dev_conf->trs = rootdev.initial_termios;
   if ( i >= rootdev.maxdev) break;
   vsp_register_dev( &rootdev, &( rootdev.devices_S[ i]), 0, i);
   if ( debug > 1) KLOG( "[%s] %s: dev #%d MJ %d (%s)\n", VSP_MOD_NAME, __FUNCTION__, i, rootdev.major0, ( rootdev.devices_S[ i]).name);
   vsp_register_dev( &rootdev, &( rootdev.devices_D[ i]), 1, i);
   if ( debug > 1) KLOG( "[%s] %s: dev #%d MJ %d (%s)\n", VSP_MOD_NAME, __FUNCTION__, i, rootdev.major1, ( rootdev.devices_S[ i]).name);
 } /* end of MAXDEV */
 KLOG( "[%s] %d devices created in /dev/vsp* with MJs [%d;%d]\n", VSP_MOD_NAME, maxdev, rootdev.major0, rootdev.major1);
 if ( debug > 1) KLOG( "[%s] %s: end\n", VSP_MOD_NAME, __FUNCTION__);

 return( VSP_SUCCESS); }

void __exit cleanup_module() {
 if ( debug > 1) KLOG( "[%s] %s: start\n", VSP_MOD_NAME, __FUNCTION__);
 vsp_unregister( &rootdev);
 if ( debug > 1) KLOG( "[%s] %s: end\n", VSP_MOD_NAME, __FUNCTION__);
 return;  }

#ifdef module_init
// module_init(init_module);
// module_exit(cleanup_module);
#endif

#ifdef BSD
int __init vsp_load( module_t _mod, int _cmd, void *_arg) {
 switch ( _cmd) {
   case MOD_LOAD:  init_module();  break;
   case MOD_UNLOAD:  cleanup_module();  break;
   default:  return( EINVAL);  break;  }
 return( VSP_SUCCESS); }
DEV_MODULE( VSP_MOD_NAME, vsp_load, NULL);
#endif /* BSD */

#ifdef MODULE_LICENSE
MODULE_LICENSE("GPL");
#endif /* MODULE_LICENSE */
#ifdef MODULE_AUTHOR
MODULE_AUTHOR("(C) by Tibbo Technology Inc., 2004-2010");
#endif /* MODULE_AUTHOR */
#ifdef MODULE_DESCRIPTION
MODULE_DESCRIPTION("Virtual Serial Port driver");
#endif /* MODULE_DESCRIPTION */
/* EXPORT_NO_SIMBOLS; */
