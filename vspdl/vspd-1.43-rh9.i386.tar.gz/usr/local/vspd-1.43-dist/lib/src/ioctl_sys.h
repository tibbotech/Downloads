#ifndef VSPM_IOCTL_SYS_H
#define VSPM_IOCTL_SYS_H

#ifdef LINUX
#include <linux/ioctl.h>
#endif /* LINUX */
#ifdef BSD
#include <sys/ioccom.h>
#endif /* BSD */

/* command */
#ifdef LINUX
#define VSP_IOCC_TYPE(nr) _IOC_TYPE(nr)  /* the group of the command */
#define VSP_IOCC_NR(nr) _IOC_NR(nr)      /* command number */
#define VSP_IOCC_DIR(nr) _IOC_DIR(nr)    /* write direction */
#define VSP_IOCC_SIZE(nr) _IOC_SIZE(nr)  /* the size of the argument */
#endif /* LINUX */
#ifdef BSD
#define VSP_IOCC_TYPE(nr) IOCGROUP(nr)	/* the group of the command */
#define VSP_IOCC_NR(nr) IOCBASECMD(nr)	/* command number */
#define VSP_IOCC_DIR(nr) ((nr) & IOC_DIRMASK)    /* write direction */
#define VSP_IOCC_SIZE(nr) IOCPARAM_LEN(nr)  /* the size of the argument */
#endif /* BSD */

/* direction */
#ifdef LINUX
#define VSP_IOCD_NONE _IOC_NONE		/* no direction */
#define VSP_IOCD_READ _IOC_READ		/* read direction */
#define VSP_IOCD_WRITE _IOC_WRITE	/* write direction */
#endif /* LINUX */
#ifdef BSD
#define VSP_IOCD_NONE IOC_VOID		/* no direction */
#define VSP_IOCD_READ IOC_IN		/* read direction */
#define VSP_IOCD_WRITE IOC_OUT	/* write direction */
#endif /* BSD */

#define VSP_IOCM_IO(type,nr) _IO(type,nr)
#define VSP_IOCM_IOR(type,nr,size) _IOR(type,nr,size)
#define VSP_IOCM_IOW(type,nr,size) _IOW(type,nr,size)
#define VSP_IOCM_IOWR(type,nr,size) _IOWR(type,nr,size)

#endif /* VSPM_IOCTL_SYS_H */
