#!/bin/sh

rcd="/etc/rc.d/init.d/"
if [ ! -d "$rcd" ]; then
  rcd="/etc/init.d/";
fi;
if [ ! -d "$rcd" ]; then
  rcd="/etc/rc.d/";
fi;

echo "stopping VSPD ..."
service=`which service`;
# LSB-compilant
if [ ! -z "${service}" ]; then
  service vspd stop
  service vspm stop
fi;
# non-LSB systems
if [ -z "${service}" ]; then
  ${rcd}/vspd stop
  ${rcd}/vspm stop
fi;
echo "removing startup scripts for vspm and vspd ..."
# LSB-compilant
chkconfig=`which chkconfig`;
if [ ! -z "${chkconfig}" ]; then
  ${chkconfig} --del vspm
  ${chkconfig} --del vspd
fi;
# non-LSB systems
if [ -z "${chkconfig}" ]; then
  rm -rf ${rcd}/vspd
  rm -rf ${rcd}/vspm
  rm -rf ${rcd}/../rc3.d/S91vspm
  rm -rf ${rcd}/../rc4.d/S91vspm
  rm -rf ${rcd}/../rc5.d/S91vspm
  rm -rf ${rcd}/../rc0.d/K10vspm
  rm -rf ${rcd}/../rc1.d/K10vspm
  rm -rf ${rcd}/../rc2.d/K10vspm
  rm -rf ${rcd}/../rc6.d/K10vspm
  rm -rf ${rcd}/../rc3.d/S92vspd
  rm -rf ${rcd}/../rc4.d/S92vspd
  rm -rf ${rcd}/../rc5.d/S92vspd
  rm -rf ${rcd}/../rc0.d/K09vspd
  rm -rf ${rcd}/../rc1.d/K09vspd
  rm -rf ${rcd}/../rc2.d/K09vspd
  rm -rf ${rcd}/../rc6.d/K09vspd
fi;
echo "DONE."
