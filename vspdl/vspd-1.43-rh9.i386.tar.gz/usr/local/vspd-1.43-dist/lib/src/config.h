#ifndef VSPM_CONFIG_H
#define VSPM_CONFIG_H

/* /proc/devices/<DEVICE_NAME> */
#define VSP_DEV_NAME "vsp"
#define VSP_DEVNEWS_DEVFS_NAME "vsp/vsps"
#define VSP_DEVNEWD_DEVFS_NAME "vsp/vspd"
#define VSP_DEVICES_DEVFS_NAME "vsp/vsps%d"
#define VSP_DEVICED_DEVFS_NAME "vsp/vspd%d"
#define VSP_DEVICES_USUAL_NAME "vsps%d"
#define VSP_DEVICED_USUAL_NAME "vspd%d"
#define VSP_DEVICES_UDEVS_NAME "vsps"
#define VSP_DEVICED_UDEVD_NAME "vspd"

/* module name for logging */
#define VSP_MOD_NAME "vspm"

#define VSP_DEBUG 1

#define VSP_SUCCESS 0

#define VSP_MAJOR0 100
#define VSP_MAJOR1 101

#define VSP_MAXDEV 128

#define VSP_MAXOPEN 10

#endif /* VSPM_CONFIG_H */
