#!/bin/sh

pkg_version="1.52"

rcd="/etc/rc.d/init.d/"
if [ ! -d "$rcd" ]; then
  rcd="/etc/init.d/";
fi;
if [ ! -d "$rcd" ]; then
  rcd="/etc/rc.d/";
fi;

echo "stopping VSPD ..."
service=`which service`;
# LSB-compilant
if [ ! -z "${service}" ]; then
  service vspd stop
  service vspm stop
fi;
# non-LSB systems
if [ -z "${service}" ]; then
  ${rcd}/vspd stop
  ${rcd}/vspm stop
fi;
rmmod vspm
echo "removing startup scripts for vspm and vspd ..."
# LSB-compilant
tmps="";
if [ -z "${tmps}" ]; then
  tmps=`which chkconfig`;
  if [ ! -z "${tmps}" ]; then
    ${tmps} --del vspm
    ${tmps} --del vspd
  fi;
fi;
if [ -z "${tmps}" ]; then
  tmps=`which update-rc.d`;
  if [ ! -z "${tmps}" ]; then
    ${tmps} -f vspm remove
    ${tmps} -f vspd remove
  fi;
fi;
if [ -d "/lib/systemd/system" ]; then
  rm -f /etc/modules-load.d/vspm.conf
  dkms remove -m vspm -v ${pkg_version} --all
  rm -f /usr/src/vspm-${pkg_version}
  systemctl stop vspd
  systemctl disable vspd
  rm -rf /lib/systemd/system/vspd.service
fi;
# non-LSB systems
if [ -z "${tmps}" ]; then
  rm -rf ${rcd}/vspd
  rm -rf ${rcd}/vspm
  rm -rf ${rcd}/../rc3.d/S91vspm
  rm -rf ${rcd}/../rc4.d/S91vspm
  rm -rf ${rcd}/../rc5.d/S91vspm
  rm -rf ${rcd}/../rc0.d/K10vspm
  rm -rf ${rcd}/../rc1.d/K10vspm
  rm -rf ${rcd}/../rc2.d/K10vspm
  rm -rf ${rcd}/../rc6.d/K10vspm
  rm -rf ${rcd}/../rc3.d/S92vspd
  rm -rf ${rcd}/../rc4.d/S92vspd
  rm -rf ${rcd}/../rc5.d/S92vspd
  rm -rf ${rcd}/../rc0.d/K09vspd
  rm -rf ${rcd}/../rc1.d/K09vspd
  rm -rf ${rcd}/../rc2.d/K09vspd
  rm -rf ${rcd}/../rc6.d/K09vspd
fi;
echo "DONE."
