/* The necessary header files */
/* Standard in kernel modules */

#ifndef VSPM_SYSHEADERS_H
#define VSPM_SYSHEADERS_H

/* Deal with CONFIG_MODVERSIONS */
/* new */
#include <linux/version.h>   /* Specifically, a module */
#include <linux/module.h>   /* Specifically, a module */
#if LINUX_VERSION_CODE < KERNEL_VERSION(2,6,20)
#include <linux/config.h>   /* some internal definitions */
#endif
#if LINUX_VERSION_CODE >= KERNEL_VERSION(2,6,20) && LINUX_VERSION_CODE < KERNEL_VERSION(2,6,33)
#include <linux/autoconf.h>   /* some internal definitions */
#endif
#if LINUX_VERSION_CODE >= KERNEL_VERSION(2,6,33)
#include <generated/autoconf.h>   /* some internal definitions */
#endif
#include <linux/init.h>   /* some internal definitions */
#if defined(CONFIG_MODVERSIONS) && !defined(MODVERSIONS)
#define MODVERSIONS
#endif /* MODVERSIONS */
#ifdef MODVERSIONS
#if LINUX_VERSION_CODE < KERNEL_VERSION(2,5,1)
#include <linux/modversions.h>
#else
#include <config/modversions.h>
#endif
#endif /* MODVERSIONS */

#include <linux/kernel.h>   /* We're doing kernel work */
#ifdef CONFIG_SMP
#define __SMP__
#endif /* CONFIG_SMP */

#ifdef CONFIG_DEVFS_FS
#include <linux/devfs_fs_kernel.h>
#endif /* CONFIG_DEVFS_FS */

#include <linux/fs.h>       /* for all character devices definition */
#if LINUX_VERSION_CODE < KERNEL_VERSION(4,8,1)
#include <asm/uaccess.h>    /* for copy_to_user and copy_from_user */
#else
#include <linux/uaccess.h>    /* for copy_to_user and copy_from_user */
#endif
#if LINUX_VERSION_CODE < KERNEL_VERSION(2,6,23)
#include <asm/semaphore.h>  /* for semaphores */
#else
#include <linux/semaphore.h>  /* for semaphores */
#endif
#include <linux/poll.h>     /* for poll/select */
#include <linux/wait.h>     /* for wait_queue_head_t */
#include <linux/sched.h>    /* for sleep_on/wake_up */
#include <linux/kthread.h>
#include <linux/delay.h>

/* for TERMIOS/TERMIO structs */
#include <linux/termios.h>

/* for tty_driver struct */
#include <linux/tty.h>
#include <linux/tty_driver.h>
#include <linux/tty_flip.h>

#include <linux/errno.h>

#include <linux/slab.h>

#endif /* VSPM_SYSHEADERS_H */
