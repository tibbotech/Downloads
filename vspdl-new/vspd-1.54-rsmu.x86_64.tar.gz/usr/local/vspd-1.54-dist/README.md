# Installation

## Requirements

**Optional**: Good to have DKMS. It rebuilds the driver automatically if kernel 
version is changed, it signups the module if required.

**Optional**: Good to have SystemD. It restarts VSPD in case of fail.

**Required**: Kernel headers or kernel source package is required. Traditionally 
it should be placed at

/usr/src/linux-headers-`uname -r`

/usr/src/linux-`uname -r`

/usr/src/kernel-`uname -r`

If the kernel headrs/source is at non-typical location you have two options:
```
ln -s mykernelpath /usr/src/linux-`uname -r`
```
or specify it in command line:
```
# KERNEL_SRC=mypath ./install.sh /usr/local/vspd
```

**Required**: GCC/G++, make. Usually the package called 'build-essentials' and
installed as the dependency for kernel headers/source.

## VSPM and VSPD setup

Under root account:
```
# ./install.sh /usr/local/vspd
```

install.sh script flow:

1. check the kernel headers/sources dir;
2. choose the makefile from lib/src/linux/ to use and copy it to lib/src/
3. run make and make modules_install
4. substitute scripts variables
5. [optional] DKMS setup (driver scr will be placed at /usr/src/vspm-x.yy)
6. scripts and binaries setup at /usr/local/vspd
7. [IF] SystemD is used - setup systemd scripts, exit
8. SystemV startup scripts setup

Setup log example:
```
# ./install.sh /usr/local/vspd
Installing to: /usr/local/vspd
kern_s:linux kern_v:6.2.0-34-generic v0:6 v1:2
Checking the kernel_src...
Searching at /usr/src/linux-headers-6.2.0-34-generic...
Kernel source/headers found at /usr/src/linux-headers-6.2.0-34-generic
Makfile template: ./lib/src/linux/Makefile-6.in
make: Entering directory '/usr/local/vspd-1.53-dist/lib/src'
make -C /usr/src/linux-headers-6.2.0-34-generic M=/usr/local/vspd-1.53-dist/lib/src
make[1]: Entering directory '/usr/src/linux-headers-6.2.0-34-generic'
warning: the compiler differs from the one used to build the kernel
  The kernel was built by: x86_64-linux-gnu-gcc-11 (Ubuntu 11.4.0-1ubuntu1~22.04) 11.4.0
  You are using:           gcc-11 (Ubuntu 11.4.0-1ubuntu1~22.04) 11.4.0
make[1]: Leaving directory '/usr/src/linux-headers-6.2.0-34-generic'
make: Leaving directory '/usr/local/vspd-1.53-dist/lib/src'
make: Entering directory '/usr/local/vspd-1.53-dist/lib/src'
make -C /usr/src/linux-headers-6.2.0-34-generic M=/usr/local/vspd-1.53-dist/lib/src modules_install
make[1]: Entering directory '/usr/src/linux-headers-6.2.0-34-generic'
  INSTALL /lib/modules/6.2.0-34-generic/extra/vspm.ko
  SIGN    /lib/modules/6.2.0-34-generic/extra/vspm.ko
  DEPMOD  /lib/modules/6.2.0-34-generic
Warning: modules_install: missing 'System.map' file. Skipping depmod.
make[1]: Leaving directory '/usr/src/linux-headers-6.2.0-34-generic'
make: Leaving directory '/usr/local/vspd-1.53-dist/lib/src'
Module is installed to /lib/modules/6.2.0-34-generic/extra/vspm.ko
Expanding ./bin/vspm.sh.in
Expanding ./bin/vspd.sh.in
Expanding ./bin/vspd.service.in
Expanding ./etc/vspd.conf.in
Expanding ./lib/src/dkms.conf.in
Expanding ./remove.sh.in
SystemD VSPD service is at /lib/systemd/system/
VSPM and VSPD will be started at boot. To start now:
modprobe vspm && systemctl restart vspd
#
```

## Troubleshooting

### Module source code build errors

Check the patches at ./lib/patches/
for example, CentOS9 Stream is using the modified kernel, some features are 
backported so need to apply patch first:
```
cd ./lib/; patch -p1 < ./5.14.0.el.patch
```

Submit the installation log to support [at] tibbo.com

### install.sh can't find the kernel headers/source dir

Find the correct path and specify it in command line:
```
# KERNEL_SRC=mypath ./install.sh /usr/local/vspd
```
OR

Install 'kernel-headers' package and re-run
```
# ./install.sh /usr/local/vspd
```

### Module is build and installed, but kernel can't find it

Check the installation log, it may say
> Warning: modules_install: missing 'System.map' file. Skipping depmod.
Try:
```
depmod -a
```

### Module won't load case it should be signed up, but it wasn't

Try to run alternative SINGup script:
```
# cd ./lib/src/;  ./sign.sh path2kheaders [path2module]
```
