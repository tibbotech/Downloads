#ifndef VSPM_IOCTL_SYS_H
#define VSPM_IOCTL_SYS_H

#include <linux/ioctl.h>

/* command */
#define VSP_IOCC_TYPE(nr) _IOC_TYPE(nr)  /* the group of the command */
#define VSP_IOCC_NR(nr) _IOC_NR(nr)      /* command number */
#define VSP_IOCC_DIR(nr) _IOC_DIR(nr)    /* write direction */
#define VSP_IOCC_SIZE(nr) _IOC_SIZE(nr)  /* the size of the argument */

/* direction */
#define VSP_IOCD_NONE _IOC_NONE		/* no direction */
#define VSP_IOCD_READ _IOC_READ		/* read direction */
#define VSP_IOCD_WRITE _IOC_WRITE	/* write direction */

#define VSP_IOCM_IO(type,nr) _IO(type,nr)
#define VSP_IOCM_IOR(type,nr,size) _IOR(type,nr,size)
#define VSP_IOCM_IOW(type,nr,size) _IOW(type,nr,size)
#define VSP_IOCM_IOWR(type,nr,size) _IOWR(type,nr,size)

#endif /* VSPM_IOCTL_SYS_H */
