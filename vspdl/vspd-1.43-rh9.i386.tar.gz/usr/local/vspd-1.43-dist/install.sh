#!/bin/sh

INSTALL="/usr/bin/install"

prefix=`pwd`;
exec_prefix="${prefix}"
nomodule="no";

prefix2=".";
if test ! -z "$1"; then
  prefix2="$1";
fi;
if test ! -z "$2" && test "$2" = yes; then
  nomodule="yes";
fi;

if test "${prefix2}" = ${prefix}; then
 echo "You don't have to install to the same path";
 echo "Use $0 <path>";
 exit 1;
fi;

if test "${prefix2}" = "."; then
 echo "You don't have to install to the same path";
 echo "Use $0 <path>";
 exit 1;
fi;

echo "installing to ${prefix2}"
./configure --with-kernel=linux --prefix=${prefix2}
if test "$nomodule" = no; then
  echo "compiling the vspm kernel module ..."
  cd ${prefix}/lib/src/
  chmod 0755 ./_makewrapper
  ./_makewrapper
  if test $? != 0; then
    echo "compilation failed, please see ./README for details";
    exit 1;
  fi;
  cp ${prefix}/lib/src/vspm.*o ${prefix}/lib/
fi;
echo "installing ..."
${INSTALL} -d ${prefix2}/bin ${prefix2}/etc ${prefix2}/lib ${prefix2}/sbin ${prefix2}/var ${prefix2}/man
${INSTALL} -m 0755 ${prefix}/bin/vspm.sh ${prefix2}/bin/vspm.sh
${INSTALL} -m 0755 ${prefix}/bin/vspd.sh ${prefix2}/bin/vspd.sh
${INSTALL} -m 0755 ${prefix}/bin/* ${prefix2}/bin/
${INSTALL} -m 0644 -b --suffix=.old ${prefix}/etc/*.conf ${prefix2}/etc/
${INSTALL} -m 0644 -b --suffix=.old ${prefix}/etc/*.conf.sample ${prefix2}/etc/
${INSTALL} -m 0755 ${prefix}/lib/*.ko ${prefix2}/lib/
${INSTALL} -m 0755 ${prefix}/sbin/* ${prefix2}/sbin/
#${INSTALL} -m 0644 ${prefix}/man/* ${prefix2}/man/
rm -rf ${prefix2}/bin/*.in

rcd="/etc/rc.d/init.d/"
if [ ! -d "$rcd" ]; then
  rcd="/etc/init.d/";
fi;
if [ ! -d "$rcd" ]; then
  rcd="/etc/rc.d/";
fi;
if [ ! -d "$rcd" ]; then
  echo "!!! neither /etc/rc.d/init.d/ , no /etc/rc.d/ found in your system"
  echo "!!! you have to install ./bin/vsp?.sh manually"
fi;
if [ -d "$rcd" ]; then
  echo "installing vspm ..."
  ${INSTALL} -m 0755 ${exec_prefix}/bin/vspm.sh ${rcd}/vspm
  echo "installing vspd ..."
  ${INSTALL} -m 0755 ${exec_prefix}/bin/vspd.sh ${rcd}/vspd
  echo "setting runlevels for vspm and vspd ..."
  chkconfig=`which chkconfig`;
  if [ ! -z "${chkconfig}" ]; then
    ${chkconfig} --add vspm
    ${chkconfig} --add vspd
  fi;
  # non-LSB system (Ubuntu, for example)
  if [ -z "${chkconfig}" ]; then
    echo "No CHKCONFIG found."
    echo "You may need to switch on your RC-scripts manually."
    ln -s -f ${rcd}/vspm ${rcd}/../rc3.d/S91vspm
    ln -s -f ${rcd}/vspm ${rcd}/../rc4.d/S91vspm
    ln -s -f ${rcd}/vspm ${rcd}/../rc5.d/S91vspm
    ln -s -f ${rcd}/vspm ${rcd}/../rc0.d/K11vspm
    ln -s -f ${rcd}/vspm ${rcd}/../rc1.d/K11vspm
    ln -s -f ${rcd}/vspm ${rcd}/../rc2.d/K11vspm
    ln -s -f ${rcd}/vspm ${rcd}/../rc6.d/K11vspm
    ln -s -f ${rcd}/vspd ${rcd}/../rc3.d/S92vspd
    ln -s -f ${rcd}/vspd ${rcd}/../rc4.d/S92vspd
    ln -s -f ${rcd}/vspd ${rcd}/../rc5.d/S92vspd
    ln -s -f ${rcd}/vspd ${rcd}/../rc0.d/K10vspd
    ln -s -f ${rcd}/vspd ${rcd}/../rc1.d/K10vspd
    ln -s -f ${rcd}/vspd ${rcd}/../rc2.d/K10vspd
    ln -s -f ${rcd}/vspd ${rcd}/../rc6.d/K10vspd
  fi;
fi;
echo "-------------------------------------"
echo "DONE. See docs for details"
