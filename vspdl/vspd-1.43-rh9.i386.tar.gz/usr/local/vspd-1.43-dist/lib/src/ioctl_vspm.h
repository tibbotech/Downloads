#ifndef VSPM_IOCTL_VSPM_H
#define VSPM_IOCTL_VSPM_H

#include "ioctl_sys.h"

#define VSPM_IOCTL_MAGIC 'T' /* magic number for the ioctl commands */

#endif /* VSPM_IOCTL_VSPM_H */
