#ifndef VSPM_H
#define VSPM_H

#ifndef TTY_FLIPBUF_SIZE
#define TTY_FLIPBUF_SIZE 512
#endif

/* module specific variables */
#if LINUX_VERSION_CODE < KERNEL_VERSION(2,5,1)
#define VSP_MOD_INC_USAGE MOD_INC_USE_COUNT
#define VSP_MOD_DEC_USAGE MOD_DEC_USE_COUNT
#define __init
#define __exit
#else /* other version */
#define VSP_MOD_INC_USAGE while(0);
#define VSP_MOD_DEC_USAGE while(0);
#endif /* other version end */
// nnn
#if LINUX_VERSION_CODE > KERNEL_VERSION(2,6,18)
#define VSP_KTERMIOS ktermios
#else
#define VSP_KTERMIOS termios
#endif
#define VSP_TERMIO termio
#define VSP_TERMIOS termios
#ifdef TCGETS2
#define VSP_TERMIOS2 termios2
#else
#define VSP_TERMIOS2 termios
#endif

/* UserToKernel & KernelToUser */
#define UTK(to,from,count) if (copy_from_user((to),(from),(count)));
#define KTU(to,from,count) if (copy_to_user((to),(from),(count)));

/* logging to kernel */
#define KLOG(fmt,args...) printk((fmt),##args)

/* TYPE & NUM macroses */
#define VSP_TYPE(dev) ((MINOR(dev) > (VSP_MAXDEV - 1)) ? 1 : 0)
#define VSP_NUM(dev) ((MINOR(dev) > (VSP_MAXDEV - 1)) ? ( MINOR(dev) - VSP_MAXDEV) : MINOR(dev))
#define VSP_TYPEC(dev) VSP_TYPE(dev)?'d':'s'
#if LINUX_VERSION_CODE < KERNEL_VERSION(2,5,1)
#define VSP_MNUMF(file) MINOR((file)->f_dentry->d_inode->i_rdev)
#define VSP_PORTN(tty) MINOR((tty)->device)
#else
#define VSP_MNUMF(file) iminor((file)->f_dentry->d_inode)
#define VSP_PORTN(tty) (tty)->index
#endif

/* state macroses */
#define VSP_STATE_OK 0x01
#define VSP_STATE_ALL 0x0F
#define VSP_GETSTATE(vspdev,mask) ((vspdev)->state & (mask))
#define VSP_SETSTATE(vspdev,mask) ((vspdev)->state |= (mask))
#define VSP_CLEARSTATE(vspdev,mask) ((vspdev)->state &= ~(mask))
/*#define VSP_CLEARSTATE(vspdev,mask) ((vspdev)->state ^= (mask))*/

/* PID macroses */
#define VSP_PID current->pid
#define VSP_PCOMM current->comm

/* file macroses */
#define VSP_NONBLOCK(file) (file)->f_flags & O_NONBLOCK
#define VSP_BLOCK(file) !(file)->f_flags & O_NONBLOCK

#if LINUX_VERSION_CODE >= KERNEL_VERSION(5,0,0)
// AlmaLinux: comment the line above and uncomment the line after
//#if LINUX_VERSION_CODE >= KERNEL_VERSION(4,18,0)
#define VSP_ACCESS_OK(type,addr,size) access_ok((addr),(size))
#else
#define VSP_ACCESS_OK(type,addr,size) access_ok((type),(addr),(size))
#endif

/* semaphore definitions */
typedef struct semaphore sema_t;
#define vsp_sema_init(sem) sema_init(&(sem),1)
#define vsp_sema_down(sem) (down_interruptible(&(sem))?-ERESTARTSYS:0)
#define vsp_sema_up(sem) up(&(sem))

/* spinlock definitions */
typedef spinlock_t spin_t;
#define vsp_spin_init(spin) spin_lock_init(&(spin))

#if LINUX_VERSION_CODE >= KERNEL_VERSION(2,3,1)
typedef wait_queue_head_t waitq_head_t;
#if LINUX_VERSION_CODE >= KERNEL_VERSION(2,12,14)
typedef struct wait_queue_entry waitq_t;
#else
typedef wait_queue_t waitq_t;
#endif
#define vsp_initwqh(head) init_waitqueue_head((head))
/* #define vsp_waitfor(wqentry,wq,spin) interruptible_sleep_on((wq)) */
#define vsp_waitfor(wqentry,wq,spin) {\
 current->state = TASK_INTERRUPTIBLE; \
 init_waitqueue_entry((wqentry),current); \
 __add_wait_queue((wq),(wqentry)); \
 spin_unlock_irq(&(spin)); \
 schedule(); \
 spin_lock_irq(&(spin)); \
 __remove_wait_queue((wq),(wqentry));  }
#endif /* LINUX_VERSION_CODE */
#if LINUX_VERSION_CODE < KERNEL_VERSION(2,3,1)
typedef struct wait_queue *waitq_head_t;
typedef struct wait_queue *waitq_t;
#define init_waitqueue_head(head) (*(head)) = NULL
#define vsp_waitfor(wqentry,wq,spin) interruptible_sleep_on((wq))
#endif /* LINUX_VERSION_CODE */
#define vsp_wakeup(wq) wake_up_interruptible((wq))

//#undef CONFIG_DEVFS_FS

/* tty_driver */
typedef struct tty_driver driver_t;

// internal devices states structure
struct VSP_DEV {
 unsigned char usage;
 unsigned char state;
 char name[ 20];
 unsigned int max_open;
 struct tty_struct *ttyp;
 sema_t sem;
 spin_t spin;
 waitq_head_t wqr, wqw;
};

#ifdef tty_struct
#error "lalala"
#endif

/* new */
#if LINUX_VERSION_CODE < KERNEL_VERSION(2,5,1)
struct tty_operations {
 int ( *open)( struct tty_struct *, struct file *);
 void ( *close)( struct tty_struct *, struct file *);
 int ( *write)( struct tty_struct *, int , const unsigned char *, int);
 void ( *put_char)( struct tty_struct *, unsigned char);
 void ( *flush_chars)( struct tty_struct *);
 int ( *write_room)( struct tty_struct *);
 int ( *chars_in_buffer)( struct tty_struct *);
 int ( *ioctl)( struct tty_struct *, struct file *, unsigned int, unsigned long);
//#ifdef CONFIG_COMPAT
#ifdef HAVE_COMPAT_IOCTL
#if LINUX_VERSION_CODE > KERNEL_VERSION(2,6,21)
 int ( *compat_ioctl)( struct tty_struct *, struct file *, unsigned int, unsigned long);
#endif
#endif
 void ( *set_termios)( struct tty_struct *, struct VSP_KTERMIOS *);
 void ( *throttle)( struct tty_struct *);
 void ( *unthrottle)( struct tty_struct *);
 void ( *stop)( struct tty_struct *);
 void ( *start)( struct tty_struct *);
 void ( *hangup)( struct tty_struct *);
 void ( *break_ctl)( struct tty_struct *, int);
 void ( *flush_buffer)( struct tty_struct *);
 void ( *set_ldisc)( struct tty_struct *);
 void ( *waitforsend)( struct tty_struct *, int);
 void ( *send_xchar)( struct tty_struct *, char);
 void ( *readproc)( char *, char **, off_t, int, int *, void *);
 void ( *writeproc)( struct file *, const char *, unsigned long, void *);
};
#endif /* linux version */

// devices configurations (up to 128)
struct VSP_DEVC {
 struct VSP_KTERMIOS trs;
 struct winsize win;
 unsigned int lines;
 pid_t pp;		// parent pid
 pid_t pg;		// process group pid
 unsigned char hioctl;	// have ioctl done on this device?
 unsigned int max_open;
};

// root point for all device structures - internal and external
struct VSP_ROOT {
 int major0;
 int major1;
 int debug;
 int maxdev;
 unsigned int usage;
 unsigned char state;
 spin_t spin;
 driver_t *driver_s;
 driver_t *driver_d;
 struct VSP_KTERMIOS initial_termios;
 struct VSP_DEV  devices_S[ VSP_MAXDEV]; /* 0 */
 struct VSP_DEV  devices_D[ VSP_MAXDEV]; /* 1 */
 struct VSP_DEVC dev_confs[ VSP_MAXDEV]; /* termios flags */
 struct tty_struct *vsp_ttyd[ VSP_MAXDEV];
 struct tty_struct *vsp_ttys[ VSP_MAXDEV];
 struct VSP_KTERMIOS    **vsp_trsd;
 struct VSP_KTERMIOS    **vsp_trss;
 struct VSP_KTERMIOS    *vsp_trsd_lc[ VSP_MAXDEV];
 struct VSP_KTERMIOS    *vsp_trss_lc[ VSP_MAXDEV];
 sema_t sem;
// FIXME
// struct file *redirap[ VSP_MAXDEV];
};

void init_termios( struct VSP_KTERMIOS *_trs) {
 ( *_trs) = tty_std_termios;
 ( *_trs).c_iflag = 0;
 ( *_trs).c_oflag = 0;
 ( *_trs).c_lflag = 0;
 ( *_trs).c_cflag = B38400|CS8|CREAD|HUPCL|CLOCAL;
// 38400 - is default in new structure too
 return;  }

void vsp_sleep_init( struct VSP_DEV *_dev) {
 init_waitqueue_head( &( _dev->wqr));
 init_waitqueue_head( &( _dev->wqw));
 return; }

void vsp_unregister_dev( struct VSP_ROOT *_root, int _mj, int _num) {
 // skip for vspSx
 if ( _mj == _root->major0) return;
 // skip for vspDx
 if ( _mj == _root->major1) return;
 return;  }

void vsp_unregister( struct VSP_ROOT *_root) {
 int i;
 driver_t *drivp_d = _root->driver_d;
 driver_t *drivp_s = _root->driver_s;
 if ( !VSP_GETSTATE( _root, VSP_STATE_OK)) return;
 _root->usage = 0;
 VSP_CLEARSTATE( _root, VSP_STATE_ALL);
 tty_unregister_driver( drivp_s);
 tty_unregister_driver( drivp_d);
 drivp_s->ttys = drivp_d->ttys = NULL;
#if LINUX_VERSION_CODE >= KERNEL_VERSION(3,8,0)
 for ( i = 0; i < VSP_MAXDEV; i++) {
   kfree( drivp_s->ports[ i]->itty);  drivp_s->ports[ i]->itty = NULL;
   kfree( drivp_d->ports[ i]->itty);  drivp_d->ports[ i]->itty = NULL;
   kfree( drivp_s->ports[ i]);  kfree( drivp_d->ports[ i]);
   drivp_s->ports[ i] = drivp_d->ports[ i] = NULL;
 }
 drivp_s->ports = drivp_d->ports = NULL;
#endif
#if LINUX_VERSION_CODE > KERNEL_VERSION(2,6,1)
#if LINUX_VERSION_CODE >= KERNEL_VERSION(5,15,0)
 tty_driver_kref_put( drivp_s);
 tty_driver_kref_put( drivp_d);
#else
 put_tty_driver( drivp_s);
 put_tty_driver( drivp_d);
#endif
#else
 kfree( drivp_d);
 kfree( drivp_s);
#endif
 return;  }

int vsp_register( struct VSP_ROOT *_root, struct tty_operations *_opsd, struct tty_operations *_opss) {
 int i = 0;
 driver_t *drivp_d = NULL;
 driver_t *drivp_s = NULL;
 VSP_CLEARSTATE( _root, VSP_STATE_ALL);
 _root->usage = 0;
 vsp_sema_init( _root->sem);
 vsp_spin_init( _root->spin);
#if LINUX_VERSION_CODE > KERNEL_VERSION(2,6,1)
#if LINUX_VERSION_CODE >= KERNEL_VERSION(5,15,0)
 _root->driver_s = drivp_s = tty_alloc_driver( VSP_MAXDEV, TTY_DRIVER_REAL_RAW);
 _root->driver_d = drivp_d = tty_alloc_driver( VSP_MAXDEV, TTY_DRIVER_REAL_RAW);
#else
 _root->driver_s = drivp_s = alloc_tty_driver( VSP_MAXDEV);
 _root->driver_d = drivp_d = alloc_tty_driver( VSP_MAXDEV);
#endif
#else
 _root->driver_s = drivp_s = kmalloc( sizeof( driver_t), GFP_KERNEL);
 _root->driver_d = drivp_d = kmalloc( sizeof( driver_t), GFP_KERNEL);
 memset( drivp_s, 0, sizeof( driver_t));
 memset( drivp_d, 0, sizeof( driver_t));
#endif
#if LINUX_VERSION_CODE >= KERNEL_VERSION(3,8,0)
 for ( i = 0; i < VSP_MAXDEV; i++) {
   drivp_s->ports[ i] = kmalloc( sizeof(*(drivp_s->ports[ i])), GFP_KERNEL);
   tty_port_init( drivp_s->ports[ i]);
   drivp_s->ports[ i]->itty = kmalloc( sizeof(*(drivp_s->ports[ i]->itty)), GFP_KERNEL);
   drivp_d->ports[ i] = kmalloc( sizeof(*(drivp_d->ports[ i])), GFP_KERNEL);
   tty_port_init( drivp_d->ports[ i]);
   drivp_d->ports[ i]->itty = kmalloc( sizeof(*(drivp_d->ports[ i]->itty)), GFP_KERNEL);
 }
#endif
#if LINUX_VERSION_CODE < KERNEL_VERSION(6,1,0)
 drivp_d->magic = drivp_s->magic = TTY_DRIVER_MAGIC;
#endif
 drivp_d->driver_name = drivp_s->driver_name = VSP_DEV_NAME;
#if LINUX_VERSION_CODE > KERNEL_VERSION(2,6,1)
 drivp_d->owner = drivp_s->owner = THIS_MODULE;
#endif
#ifdef CONFIG_DEVFS_FS
#if LINUX_VERSION_CODE > KERNEL_VERSION(2,5,1)
 drivp_d->devfs_name = VSP_DEVNEWD_DEVFS_NAME;
 drivp_s->devfs_name = VSP_DEVNEWS_DEVFS_NAME;
#endif
 drivp_d->name = VSP_DEVICED_DEVFS_NAME;
 drivp_s->name = VSP_DEVICES_DEVFS_NAME;
#elif UDEV
 drivp_d->name = VSP_DEVICED_UDEVD_NAME;
 drivp_s->name = VSP_DEVICES_UDEVS_NAME;
#else /* no DEVFS or UDEV */
 drivp_d->name = VSP_DEVICED_USUAL_NAME;
 drivp_s->name = VSP_DEVICES_USUAL_NAME;
#endif
 drivp_d->major = VSP_MAJOR1;
 drivp_s->major = VSP_MAJOR0;
 drivp_d->minor_start = drivp_s->minor_start = 0;
 drivp_d->num = drivp_s->num = VSP_MAXDEV;
 drivp_d->type = drivp_s->type = TTY_DRIVER_TYPE_SERIAL;
 drivp_d->subtype = drivp_s->subtype = SERIAL_TYPE_NORMAL;
 drivp_d->init_termios = drivp_s->init_termios = _root->initial_termios;
 drivp_d->flags = drivp_s->flags = TTY_DRIVER_REAL_RAW;
#if LINUX_VERSION_CODE < KERNEL_VERSION(2,5,1)
 drivp_d->refcount = drivp_s->refcount = &( _root->usage);
 drivp_d->table = _root->vsp_ttyd;
 drivp_s->table = _root->vsp_ttys;
#else
#if LINUX_VERSION_CODE < KERNEL_VERSION(2,6,28)
 drivp_d->refcount = drivp_s->refcount = _root->usage;
#endif
 drivp_d->ttys = _root->vsp_ttyd;
 drivp_s->ttys = _root->vsp_ttys;
#endif
 // LL
 _root->vsp_trss = kmalloc( VSP_MAXDEV*sizeof( _root->vsp_trss), GFP_KERNEL);
 _root->vsp_trsd = kmalloc( VSP_MAXDEV*sizeof( _root->vsp_trsd), GFP_KERNEL);
 for ( i = 0; i < VSP_MAXDEV; i++) {
   _root->vsp_trss[ i] = kzalloc(sizeof(struct tty_struct), GFP_KERNEL);
   _root->vsp_trsd[ i] = kzalloc(sizeof(struct tty_struct), GFP_KERNEL);
 }
 drivp_d->termios = _root->vsp_trsd;
 drivp_s->termios = _root->vsp_trss;
#if LINUX_VERSION_CODE < KERNEL_VERSION(3,3,0)
 drivp_d->termios_locked = _root->vsp_trsd_lc;
 drivp_s->termios_locked = _root->vsp_trss_lc;
#endif
#if LINUX_VERSION_CODE >= KERNEL_VERSION(2,6,0)
 tty_set_operations( drivp_d, _opsd);
 tty_set_operations( drivp_s, _opss);
#else
 drivp_d->open = _opsd->open;
 drivp_s->open = _opss->open;
 drivp_d->close = _opsd->close;
 drivp_s->close = _opss->close;
 drivp_d->write = _opsd->write;
 drivp_s->write = _opss->write;
// drivp_d->put_char = _opsd->put_char;
// drivp_s->put_char = _opss->put_char;
// drivp->flush = _ops->flush;
 drivp_d->write_room = _opsd->write_room;
 drivp_s->write_room = _opss->write_room;
 drivp_d->chars_in_buffer = _opsd->chars_in_buffer;
 drivp_s->chars_in_buffer = _opss->chars_in_buffer;
 drivp_d->ioctl = _opsd->ioctl;
 drivp_s->ioctl = _opss->ioctl;
// test!
 drivp_d->set_termios = _opsd->set_termios;
 drivp_s->set_termios = _opss->set_termios;
#if LINUX_VERSION_CODE > KERNEL_VERSION(2,5,1)
 drivp_d->tiocmget = _opsd->tiocmget;
 drivp_s->tiocmget = _opss->tiocmget;
 drivp_d->tiocmset = _opsd->tiocmset;
 drivp_s->tiocmset = _opss->tiocmset;
#endif
// drivp_d->flush_buffer = _opsd->flush_chars;
// drivp_s->flush_buffer = _opss->flush_chars;
 drivp_d->throttle = _opsd->throttle;
 drivp_s->throttle = _opss->throttle;
 drivp_d->unthrottle = _opsd->unthrottle;
 drivp_s->unthrottle = _opss->unthrottle;
 drivp_d->stop = _opsd->stop;
 drivp_s->stop = _opss->stop;
 drivp_d->start = _opsd->start;
 drivp_s->start = _opss->start;
 drivp_d->hangup = _opsd->hangup;
 drivp_s->hangup = _opss->hangup;
 drivp_d->break_ctl = _opsd->break_ctl;
 drivp_s->break_ctl = _opss->break_ctl;
 drivp_d->flush_chars = _opsd->flush_chars;
 drivp_s->flush_chars = _opss->flush_chars;
 drivp_d->set_ldisc = _opsd->set_ldisc;
 drivp_s->set_ldisc = _opss->set_ldisc;
 drivp_d->send_xchar = _opsd->send_xchar;
 drivp_s->send_xchar = _opss->send_xchar;
// test end!
#endif
 if ( tty_register_driver( drivp_d) < 0) return( -1);
 if ( tty_register_driver( drivp_s) < 0) return( -1);
 VSP_SETSTATE( _root, VSP_STATE_OK);
 return( 1); }

void vsp_register_dev( struct VSP_ROOT *_root, struct VSP_DEV *_dev, int _type, int _num) {
 VSP_CLEARSTATE( _dev, VSP_STATE_ALL);
 _dev->usage = 0;
 _dev->max_open = VSP_MAXOPEN;
 memset( &( _dev->name), 0, sizeof( char) * 20);
 sprintf( _dev->name, "%s%c%d", VSP_DEV_NAME, ( _type == 0 ? 's' : 'd'), _num);
 VSP_SETSTATE( _dev, VSP_STATE_OK);
 vsp_sema_init( _dev->sem);
 vsp_sleep_init( _dev);
 vsp_spin_init( _dev->spin);
 return;  }

#endif /* VSPM_H */
