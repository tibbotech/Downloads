5.14.0.el.patch is for CentOS9 Stream.
  The kernel have some backports which makes the headers imcompatible.