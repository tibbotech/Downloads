#!/bin/sh

command -v mokutil &> /dev/null
if [ $? -ne 0 ]; then
  echo "No 'mokutil' app found"
  exit 0;
fi;
command -v openssl &> /dev/null
if [ $? -ne 0 ]; then
  echo "No 'openssl' app found"
  exit 0;
fi;

if [ $# -lt 1 ]; then
  echo "Usage: ${0} <kernel_headers_path> [module]"
  exit 1;
fi;

if [ ! -x "${1}/scripts/sign-file" ]; then
  echo "There is no /scripts/sign-file at ${1}"
  exit 1;
fi;

x=""
if [ ! -z "${1}" ]; then
  cf="${1}/.config"
  x=`grep CONFIG_MODULE_SIG_HASH ${cf} | sed -e 's/.*SIG_HASH="//g' | sed -e 's/"//g'`
fi;
if [ -z "${x}" ]; then
  cf="/boot/config-"`uname -r`
  echo "Trying ${cf}"
  x=`grep CONFIG_MODULE_SIG_HASH ${cf} | sed -e 's/.*SIG_HASH="//g' | sed -e 's/"//g'`
fi;
if [ -z "${x}" ]; then
  echo "Seems module signing is not needed"
  exit 0;
fi;

echo "Module should be signed with ${x} key"
KEYT="${x}"

D=`pwd`
install -d ${D}/certs
if [ ! -f "${D}/certs/MOK.der" ]; then
  openssl req -new -x509 -newkey rsa:2048 \
  -keyout ${D}/certs/MOK.priv -outform DER -out ${D}/certs/MOK.der \
  -nodes -days 36500 -subj "/CN=Tibbo VSPD/"
  echo "Importing key ${D}/certs/MOK.der ..."
  mokutil --import ${D}/certs/MOK.der
  echo "New keys are imported. Reboot you Linux after"
fi;

if [ ! -z "${2}" ]; then
  echo "Signing ${2}"
  ${1}/scripts/sign-file ${KEYT} ${D}/certs/MOK.priv ${D}/certs/MOK.der ${2}
  exit 0;
fi;

do_copy=0
kmod1="./vspm.ko"
kmod0=$(find /lib/modules/`uname -r`/ -name "vspm.ko")
kmod=""
if [ -f "${kmod0}" ]; then  kmod="${kmod0}";
else if [ -f "${kmod1}" ]; then kmod="${kmod1}";  do_copy=1;  fi;

echo "Signing ${kmod}..."
${1}/scripts/sign-file ${KEYT} ${D}/certs/MOK.priv ${D}/certs/MOK.der ${kmod}
if [ ${do_copy} -ne 0 ]; then
  install -d /lib/modules/`uname -r`/extra
  install ${kmod} /lib/modules/`uname -r`/extra/vspm.ko
fi;
