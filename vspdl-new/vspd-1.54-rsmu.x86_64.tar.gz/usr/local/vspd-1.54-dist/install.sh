#!/bin/sh

dir_src=$(dirname $0)
dir_dst="$1"
#pkg_version="1.53"
pkg_version=$(echo $(basename $(cd $(dirname $0) && pwd)) | sed -e 's/vspd-//g' | sed -e 's/-dist//g')

if [ -z "${1}" ]; then
  echo "Usage: ${0} <path>"
  exit 1;
fi;

if [ "${dir_dst}" = "${dir_src}" ]; then
  echo "You don't have to install to the same path";
  exit 1;
fi;

echo "Installing to: ${dir_dst}"
kern_s=`uname -s | tr '[:upper:]' '[:lower:]'`
kern_v=`uname -r`
kern_v0=`uname -r | sed -e 's/\([0-9]*\)\..*/\1/g'`
kern_v1=`uname -r | sed -e 's/[0-9]*\.\([0-9]*\)\..*/\1/g'`
echo "kern_s:${kern_s} kern_v:${kern_v} v0:${kern_v0} v1:${kern_v1}"

# find the kernel headers
echo "Checking the kernel_src..."
if [ -z "${KERNEL_SRC}" ]; then
  tkd="/usr/src/${kern_s}-headers-${kern_v}";
  echo "Searching at ${tkd}..."
  if [ -d "${tkd}" ]; then  KERNEL_SRC="${tkd}";  fi;
fi;
if [ -z "${KERNEL_SRC}" ]; then
  tkd="/usr/src/${kern_s}-${kern_v}";
  echo "Searching at ${tkd}..."
  if [ -d "${tkd}" ]; then  KERNEL_SRC="${tkd}";  fi;
fi;
if [ -z "${KERNEL_SRC}" ]; then
  tkd="/usr/src/kernel-${kern_v}";
  echo "Searching at ${tkd}..."
  if [ -d "${tkd}" ]; then  KERNEL_SRC="${tkd}";  fi;
fi;
if [ -z "${KERNEL_SRC}" ]; then
  echo "Kernel source/headers not found. Try KERNEL_SRC=.. ${0}"
  exit 1;
fi;
echo "Kernel source/headers found at ${KERNEL_SRC}"

# detect the UDEV
tmp=`ps auxw | grep "udevd" | grep -v "grep"`;
if [ ! -z "$tmp" ]; then  UDEV_FLAGS="-DUDEV";  fi;
tmp=`ps auxw | grep "systemd" | grep -v "grep"`;
if [ ! -z "$tmp" ]; then  UDEV_FLAGS="-DUDEV";  fi;

vsp_fpath=""
tmp=`mount | grep "devfs" | grep -v "grep"`;
if [ ! -z "$tmp" ]; then  vsp_fpath="vsp/";  fi;

# detect the nakefile to use
mkf=""
if [ -z "${mkf}" ]; then
  tf="${dir_src}/lib/src/${kern_s}/Makefile-${kern_v0}.${kern_v1}.in"
  if [ -f "${tf}" ]; then  mkf="${tf}";  fi;
fi;
if [ -z "${mkf}" ]; then
  tf="${dir_src}/lib/src/${kern_s}/Makefile-${kern_v0}.in"
  if [ -f "${tf}" ]; then  mkf="${tf}";  fi;
fi;
echo "Makfile template: ${mkf}"
install -m 0644 ${mkf} ${dir_src}/lib/src/Makefile
#cd ${dir_src}/lib/src
( \
make -C ${dir_src}/lib/src KERNEL_SRC="${KERNEL_SRC}" UDEV_FLAGS="${UDEV_FLAGS}" && \
make -C ${dir_src}/lib/src KERNEL_SRC="${KERNEL_SRC}" UDEV_FLAGS="${UDEV_FLAGS}" modules_install \
) || exit 1

kmod0=$(find /lib/modules/`uname -r`/ -name "vspm.ko")
if [ ! -z "${kmod0}" ]; then
  echo "Module is installed to ${kmod0}"
  echo "Running depmod -A, it may take up to 20 seconds..."
  depmod -A
fi;

# expanding variables in configs and scripts
in_files="${dir_src}/bin/vspm.sh.in ${dir_src}/bin/vspd.sh.in"
in_files="${in_files} ${dir_src}/bin/vspd.service.in"
in_files="${in_files} ${dir_src}/etc/vspd.conf.in"
in_files="${in_files} ${dir_src}/lib/src/dkms.conf.in"
in_files="${in_files} ${dir_src}/remove.sh.in"

for i in ${in_files}; do
  if [ ! -f "${i}" ]; then  continue;  fi;
  nf=$(echo ${i} | sed -e 's/\.in//g')
  echo "Expanding ${i}"
  cat ${i} | \
  sed "s|@prefix@|${dir_dst}|g" | \
  sed "s|@vsp_fpath@|${vsp_fpath}|g" | \
  sed "s|@pkg_version@|${pkg_version}|g" \
  > ${nf}
done;
chmod 755 ${dir_src}/remove.sh

hash dkms 2> /dev/null
if [ $? -eq 0 ]; then
  echo "Installing vspm DKMS..."
  ln -s ${dir_src}/lib/src/ /usr/src/vspm-${pkg_version} && \
  dkms add -m vspm -v ${pkg_version} && \
  dkms build -m vspm -v ${pkg_version} && \
  dkms install -m vspm -v ${pkg_version}
fi;

install -d ${dir_dst}/bin ${dir_dst}/etc ${dir_dst}/lib ${dir_dst}/sbin ${dir_dst}/var ${dir_dst}/man
install -m 0755 ${dir_src}/bin/vspm.sh ${dir_dst}/bin/vspm.sh
install -m 0755 ${dir_src}/bin/vspd.sh ${dir_dst}/bin/vspd.sh
install -m 0755 ${dir_src}/bin/* ${dir_dst}/bin/
install -m 0644 -b --suffix=.old ${dir_src}/etc/*.conf ${dir_dst}/etc/
install -m 0644 -b --suffix=.old ${dir_src}/etc/*.conf.sample ${dir_dst}/etc/
if [ ! -z "${kmod0}" ]; then
  install -m 0755 ${kmod0} ${dir_dst}/lib/
else
  install -m 0755 ${dir_src}/lib/src/vspm.ko ${dir_dst}/lib/
fi;
install -m 0755 ${dir_src}/sbin/* ${dir_dst}/sbin/
#install -m 0644 ${prefix}/man/* ${prefix2}/man/
rm -rf ${dir_dst}/bin/*.in

if [ -d "/lib/systemd" ]; then
  echo "SystemD VSPD service is at /lib/systemd/system/";
  echo "vspm" > /etc/modules-load.d/vspm.conf
  install -m 0644 ${dir_src}/bin/vspd.service /lib/systemd/system/
  systemctl daemon-reload && systemctl enable vspd
  if [ $? -eq 0 ]; then
    echo "VSPM and VSPD will be started at boot. To start now:"
    echo "modprobe vspm && systemctl restart vspd"
    exit 0;
  else
    echo "Problem installing Systemd service"
  fi;
fi;

echo "RC classical startup scripts"
rcd="/etc/rc.d/init.d/"
if [ ! -d "$rcd" ]; then
  rcd="/etc/init.d/";
fi;
if [ ! -d "$rcd" ]; then
  rcd="/etc/rc.d/";
fi;
if [ ! -d "$rcd" ]; then
  echo "!!! neither /etc/rc.d/init.d/ , no /etc/rc.d/ found in your system"
  echo "!!! you have to install ./bin/vsp?.sh manually"
  exit 1;
fi;

echo "vspm to ${rcd}"
install -m 0755 ${dir_src}/bin/vspm.sh ${rcd}/vspm
echo "vspd to ${rcd}"
install -m 0755 ${dir_src}/bin/vspd.sh ${rcd}/vspd
echo "Setting runlevels for vspm and vspd ..."
# LSB-compilant
tmps="";
if [ -z "${tmps}" ]; then
  tmps=`which chkconfig`;
  if [ ! -z "${tmps}" ]; then
    ${tmps} --add vspm
    ${tmps} --add vspd
  fi;
fi;
if [ -z "${tmps}" ]; then
  tmps=`which update-rc.d`;
  if [ ! -z "${tmps}" ]; then
    ${tmps} vspm defaults
    ${tmps} vspd defaults
  fi;
fi;
# non-LSB system (old Ubuntu, for example)
 if [ -z "${tmps}" ]; then
  echo "No CHKCONFIG nor UPDATE-RC.D found."
  echo "You may need to switch on your RC-scripts manually."
  ln -s -f ${rcd}/vspm ${rcd}/../rc3.d/S91vspm
  ln -s -f ${rcd}/vspm ${rcd}/../rc4.d/S91vspm
  ln -s -f ${rcd}/vspm ${rcd}/../rc5.d/S91vspm
  ln -s -f ${rcd}/vspm ${rcd}/../rc0.d/K11vspm
  ln -s -f ${rcd}/vspm ${rcd}/../rc1.d/K11vspm
  ln -s -f ${rcd}/vspm ${rcd}/../rc2.d/K11vspm
  ln -s -f ${rcd}/vspm ${rcd}/../rc6.d/K11vspm
  ln -s -f ${rcd}/vspd ${rcd}/../rc3.d/S92vspd
  ln -s -f ${rcd}/vspd ${rcd}/../rc4.d/S92vspd
  ln -s -f ${rcd}/vspd ${rcd}/../rc5.d/S92vspd
  ln -s -f ${rcd}/vspd ${rcd}/../rc0.d/K10vspd
  ln -s -f ${rcd}/vspd ${rcd}/../rc1.d/K10vspd
  ln -s -f ${rcd}/vspd ${rcd}/../rc2.d/K10vspd
  ln -s -f ${rcd}/vspd ${rcd}/../rc6.d/K10vspd
fi;
echo "DONE. See docs for details"
